O   <-  0L
L   <-  1L

OL  <-  0:1
LO  <-  1:0
LL  <- c(-L, L)

LOL <- -1:1
